// Arsha Niksa
// Student Number: 400108706
// 04/01/2022

import GUI.GameFrame;
import models.Game;

public class GuiMain {
    public static void main(String[] args) {
        Game game = new Game();
        GameFrame frame = new GameFrame(game);
    }
}
