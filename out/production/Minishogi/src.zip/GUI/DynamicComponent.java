package GUI;

public interface DynamicComponent {
    public void update(GameStatus gameStatus);
}
