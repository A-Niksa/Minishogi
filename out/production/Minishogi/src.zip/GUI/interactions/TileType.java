package GUI.interactions;

public enum TileType {
    BOARD,
    HAND
}
